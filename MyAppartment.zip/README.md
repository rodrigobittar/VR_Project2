# P2: My Virtual Appartment[Version 1.0]
**P2: My Virtual Appartment** is a VR app that runs on Android. The app is built using Unity3D platform. This is app is VR appartment with various items in it that you can explore using Google cardboard.

## Getting started

###Requirements

- Android version 4.4(KitKat) or higher
- This app has been tested on a [Sony Xperia Z2(D603)](http://www.sonymobile.com/global-en/products/phones/xperia-z2/specifications/) running android 6.0(Marshmallow)

###Installation

- Download and extract the project zip file named "MyAppartment.zip"

- Copy the file named "MyAppartment.apk" into your Android phone using a usb cable

- Install the copied ".apk" file in your phone

- Run the app named "Course 2 Project"

###Resources
This project was biult using [Unity3D](https://unity3d.com/) using a tutorial from Project 2 of the [Udacity Virtual Reality Nanodegree](https://classroom.udacity.com/nanodegrees/nd017/syllabus)

####Contact
My name is Tientcheu Larry, I took about 3 hours to complete this project, the things i liked the most was the setting up of lights and the positioning of various game objects. I found setting up the trigger for the animation challenging.

